import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Navbar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <nav className="bg-blue-600 text-white p-4 flex justify-between items-center">
            <h1 className="text-lg font-bold">Creator Dashboard</h1>
            <div>
                {user ? (
                    <button onClick={handleLogout} className="bg-white text-blue-600 px-3 py-1 rounded">
                        Logout
                    </button>
                ) : (
                    <>
                        <Link to="/" className="mr-4">Login</Link>
                        <Link to="/register">Register</Link>
                    </>
                )}
            </div>
        </nav>
    );
}

export default Navbar;
