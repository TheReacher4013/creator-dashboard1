import React from "react";
import "./Feed.css";

const Feed = ({ post, onSave, onReport }) => {
    return (
        <div className="post-card">
            {post.image && <img src={post.image} alt={post.title} className="post-image" />}
            <h3>{post.title}</h3>
            <p>{post.content}</p>
            <div className="post-buttons">
                <button onClick={() => onSave(post._id)}>Save</button>
                <button onClick={() => onReport(post._id)}>Report</button>
            </div>
        </div>
    );
};

export default Feed;
