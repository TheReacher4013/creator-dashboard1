import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export const loginUser = async (email, password) => {
    const res = await axios.post(`${API_URL}/auth/login`, { email, password });
    return res.data.token;
};

export const registerUser = async (email, password) => {
    await axios.post(`${API_URL}/auth/register`, { email, password });
};
