import React, { useEffect, useState } from "react";
import axios from "axios";
import '../styles/DashboardPage.css';


const Dashboard = () => {
    const [credits, setCredits] = useState(0);

    useEffect(() => {
        axios.get("http://localhost:5000/api/user/me")
            .then(res => setCredits(res.data.credits))
            .catch(err => console.log(err));
    }, []);

    return (
        <div style={{ padding: "20px" }}>
            <h2>Dashboard</h2>
            <p><strong>Credit Points:</strong> {credits}</p>
        </div>
    );
};

export default Dashboard;
