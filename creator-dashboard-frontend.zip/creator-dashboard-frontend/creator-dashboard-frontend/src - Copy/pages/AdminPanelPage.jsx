import '../styles/AdminPanel.css';

function AdminPanelPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold mb-4">Admin Panel</h1>
            <p className="text-gray-600">Manage users, credits, and reports here.</p>
        </div>
    );
}

export default AdminPanelPage;
