import React, { useEffect, useState } from "react";
import axios from "axios";
import "./FeedPage.css";

const FeedPage = () => {
    const [posts, setPosts] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        axios.get("http://localhost:5000/api/feed")
            .then(res => setPosts(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleSave = async (postId) => {
        try {
            const userId = localStorage.getItem("userId");
            const res = await axios.post("http://localhost:5000/api/feed/save", { postId, userId });
            setMessage(res.data.message || "Saved successfully!");
        } catch (error) {
            setMessage(error.response?.data?.error || "Failed to save");
        }
    };

    const handleReport = async (postId) => {
        try {
            const userId = localStorage.getItem("userId");
            const res = await axios.post("http://localhost:5000/api/feed/report", { postId, userId });
            setMessage(res.data.message || "Reported successfully!");
        } catch (error) {
            setMessage(error.response?.data?.error || "Failed to report");
        }
    };

    return (
        <div className="feed-container">
            <h2>Feed</h2>
            {message && <p className="message">{message}</p>}
            {posts.map(post => (
                <div key={post._id} className="feed-card">
                    <img src={post.image} alt={post.title} className="post-image" />
                    <h3>{post.title}</h3>
                    <p>{post.content}</p>
                    <div className="feed-buttons">
                        <button onClick={() => handleSave(post._id)}>Save</button>
                        <button onClick={() => handleReport(post._id)}>Report</button>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default FeedPage;
