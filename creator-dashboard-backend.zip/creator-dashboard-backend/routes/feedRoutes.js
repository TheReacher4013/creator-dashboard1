const express = require("express");
const router = express.Router();
const { getFeed, savePost, reportPost } = require("../controllers/feedController");

router.get("/", getFeed);
router.post("/save", savePost);
router.post("/report", reportPost);

module.exports = router;
