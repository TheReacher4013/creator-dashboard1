// File: backend/routes/userRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/authMiddleware');

router.get('/me', auth, async (req, res) => {
    const user = await User.findById(req.user.id);
    res.json({ credits: user.credits });
});

module.exports = router;
