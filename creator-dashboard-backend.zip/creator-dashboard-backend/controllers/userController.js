const User = require('../models/User');

// Get user profile
exports.getProfile = async (req, res) => {
    res.json(req.user);
};

// Update credits manually (admin)
exports.updateCredits = async (req, res) => {
    const { userId, credits } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.credits = credits;
    await user.save();

    res.json({ message: 'Credits updated' });
};
