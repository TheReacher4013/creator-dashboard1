const User = require("../models/User");

const dummyPosts = [
    {
        _id: "1",
        title: "Post 1",
        content: "THALA FOR A REASON content",
        image: "http://localhost:5000/public/images/Thala7.jpg"
    },
    {
        _id: "2",
        title: "Post 2",
        content: "Good home Sweet Home content",
        image: "http://localhost:5000/public/images/home.jpg"
    },
    {
        _id: "3",
        title: "Post 3",
        content: "ANIME content",
        image: "http://localhost:5000/public/images/anime.jpg"
    }
];


// ---------------------- GET FEED ----------------------
exports.getFeed = (req, res) => {
    res.json(dummyPosts);
};

// ---------------------- SAVE POST ----------------------
exports.savePost = async (req, res) => {
    const { userId } = req.body;

    if (!userId) return res.status(400).json({ error: "User ID is required" });

    try {
        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ error: "User not found" });

        if (user.credits <= 0) {
            return res.status(400).json({ error: "Not enough credits" });
        }

        user.credits -= 1;
        await user.save();

        res.json({ message: "Post saved!", remainingCredits: user.credits });
    } catch (err) {
        res.status(500).json({ error: "Server error" });
    }
};

// ---------------------- REPORT POST ----------------------
exports.reportPost = async (req, res) => {
    const { userId } = req.body;

    if (!userId) return res.status(400).json({ error: "User ID is required" });

    try {
        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ error: "User not found" });

        if (user.credits <= 0) {
            return res.status(400).json({ error: "Not enough credits" });
        }

        user.credits -= 1;
        await user.save();

        res.json({ message: "Post reported!", remainingCredits: user.credits });
    } catch (err) {
        res.status(500).json({ error: "Server error" });
    }
};
