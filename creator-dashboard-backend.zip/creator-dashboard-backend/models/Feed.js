const mongoose = require('mongoose');

const feedSchema = new mongoose.Schema({
    title: String,
    link: String,
    source: String,
    reported: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Feed', feedSchema);
