// creator-dashboard-backend/models/Post.js
const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
    content: String,
    author: String,
    createdAt: {
        type: Date,
        default: Date.now,
    },
    saves: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    reports: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    shareCount: {
        type: Number,
        default: 0,
    },
});

module.exports = mongoose.model('Post', postSchema);
