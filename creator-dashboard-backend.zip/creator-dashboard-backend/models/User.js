const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    email: String,
    password: String,
    credits: {
        type: Number,
        default: 10,
    },
});

module.exports = mongoose.model("User", userSchema);
